package classes;

import java.util.Set;

/** Consulta utilitzada per obtenir els noms dels Autors que començen per un prefix (ja sigui el nom o un cognom).
 * @author Oscar Ramos Nuñez (oscar.ramos.nunez@estudiantat.upc.edu)
 */
public class ConsultaAutors {
    
    /** Arbre de cerca que emmagatzema els autors. */
    private TernaryTreeAutor autors;

    /** COnstructora per defecte.
     * @return Consultora Autors empty
     */
    public ConsultaAutors() {
        autors = new TernaryTreeAutor();
    }

    /** Insereix l'autor en l'arbre de cerca per prefix. Per cada autor insereix el nom i cada cognom (per tal de poder fer també la cerca per un prefix d'un cognom).
     * @param autor
     */
    public void addAutor(Frase autor) {
        String nom_cognom = autor.toString();
       
        while (nom_cognom.length() > 0) {
            //inserim l'autor
            autors.inserirAutor(autor, nom_cognom, 0);
            
            //esborrem la primera paraula de el String
            int ini = 0;
            int length = nom_cognom.length();
            while (ini < length && Character.isLetter(nom_cognom.charAt(ini))) ++ini;
            if (ini >= length) break;
            else {
                //vol dir que hem trobat un espai
                ++ini;
                nom_cognom = nom_cognom.substring(ini, length);
            }
        }
    }

    /** Funció consulta. Retorna els autors els quals compleixen el prefix.
     * @return Set de Frases on cada frase és un autor.
     * @param prefix
     */
    public Set<Frase> donaAutors(String prefix) {
        //retorna el Set d'autors que compleixen el prefix
        Set<Frase> result = autors.obtenirAutors(prefix, 0);
        return result;
    }
}
